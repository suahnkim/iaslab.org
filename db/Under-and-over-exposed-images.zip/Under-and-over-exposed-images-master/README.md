# Under-and-over-exposed-images
Images are provided by Rolf Lussi during internship @ Korea University

Images has been resized, cropped and saved as png (originally JPEG)

Please make appropriate citation for reuse

Rolf Lussi, under and over exposed image suite, Korea University, 2014

OR

Kim, S., Lussi, R., Qu, X., & Kim, H. J. (2015, November). Automatic contrast enhancement using reversible data hiding. In Information Forensics and Security (WIFS), 2015 IEEE International Workshop on (pp. 1-5). IEEE.
